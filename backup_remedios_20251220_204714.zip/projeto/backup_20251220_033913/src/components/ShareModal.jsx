import React, { useState } from 'react';
import Modal from './ui/Modal';
import Button from './ui/Button';
import Input from './ui/Input';
import { Users, Mail, Trash2, Eye, Edit2, Shield, ChevronDown } from 'lucide-react';

/**
 * Modal for sharing patient access with other users
 */
const ShareModal = ({ isOpen, onClose, patient, onShare, onUnshare }) => {
    const [email, setEmail] = useState('');
    const [permission, setPermission] = useState('view');
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [userToDelete, setUserToDelete] = useState(null);

    const handleShare = async () => {
        if (!email.trim()) return;

        setIsSubmitting(true);
        try {
            await onShare(patient.id, email.trim(), permission);
            setEmail('');
            setPermission('view');
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleUnshareClick = (shareEmail) => {
        setUserToDelete(shareEmail);
    };

    const confirmUnshare = async () => {
        if (userToDelete) {
            await onUnshare(patient.id, userToDelete);
            setUserToDelete(null);
        }
    };

    const sharedUsers = patient?.sharedWith || [];

    // Confirmation View
    if (userToDelete) {
        return (
            <Modal isOpen={isOpen} onClose={() => setUserToDelete(null)} title="Remover Acesso">
                <div className="text-center py-6">
                    <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center text-rose-500 mx-auto mb-4">
                        <Trash2 size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">Confirmar Remoção</h3>
                    <p className="text-slate-600 mb-6">
                        Deseja realmente remover o acesso de <span className="font-semibold">{userToDelete}</span>?
                    </p>
                    <div className="flex gap-3">
                        <Button variant="ghost" onClick={() => setUserToDelete(null)} className="flex-1">
                            Cancelar
                        </Button>
                        <Button variant="danger" onClick={confirmUnshare} className="flex-1">
                            Confirmar
                        </Button>
                    </div>
                </div>
            </Modal>
        );
    }

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Compartilhar Paciente">
            <div className="space-y-6">
                {/* Info Section */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                        <Shield className="text-blue-600 mt-0.5" size={20} />
                        <div className="flex-1">
                            <h4 className="font-semibold text-blue-900 text-sm">Como funciona?</h4>
                            <p className="text-blue-700 text-xs mt-1">
                                Compartilhe o acesso a este paciente com outros usuários.
                                Eles poderão visualizar ou editar conforme a permissão concedida.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Add User Form */}
                <div className="space-y-4">
                    <h3 className="font-semibold text-slate-900">Adicionar Acesso</h3>

                    <Input
                        label="Email do Usuário"
                        type="email"
                        placeholder="usuario@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        icon={<Mail size={18} />}
                    />

                    <label className="text-sm font-semibold text-slate-700 ml-1">
                        Permissão
                    </label>

                    {/* Custom Dropdown to allow bold text */}
                    <div className="relative">
                        <button
                            type="button"
                            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                            className="w-full px-4 py-3 text-left rounded-xl border-2 border-slate-500 dark:border-slate-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white flex items-center justify-between hover:border-slate-600 shadow-sm focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-200"
                        >
                            <span>
                                <span className="font-bold text-slate-800">
                                    {permission === 'view' ? 'Visualizar' : 'Editar'}
                                </span>
                                <span className="text-slate-500 font-normal">
                                    {permission === 'view' ? ' - Pode apenas ver os dados' : ' - Pode visualizar e modificar'}
                                </span>
                            </span>
                            <ChevronDown size={20} className={`text-slate-400 transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''}`} />
                        </button>

                        {isDropdownOpen && (
                            <>
                                <div
                                    className="fixed inset-0 z-10"
                                    onClick={() => setIsDropdownOpen(false)}
                                />
                                <div className="absolute z-20 w-full mt-2 bg-white border border-slate-100 rounded-xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                    <button
                                        type="button"
                                        onClick={() => { setPermission('view'); setIsDropdownOpen(false); }}
                                        className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-50 flex items-center"
                                    >
                                        <div className="w-2 h-2 rounded-full bg-blue-500 mr-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                        <span>
                                            <span className="font-bold text-slate-900">Visualizar</span>
                                            <span className="text-slate-500"> - Pode apenas ver os dados</span>
                                        </span>
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => { setPermission('edit'); setIsDropdownOpen(false); }}
                                        className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors flex items-center"
                                    >
                                        <div className="w-2 h-2 rounded-full bg-green-500 mr-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                        <span>
                                            <span className="font-bold text-slate-900">Editar</span>
                                            <span className="text-slate-500"> - Pode visualizar e modificar</span>
                                        </span>
                                    </button>
                                </div>
                            </>
                        )}
                    </div>

                    <Button
                        onClick={handleShare}
                        disabled={!email.trim() || isSubmitting}
                        className="w-full"
                    >
                        <Users size={18} className="mr-2" />
                        {isSubmitting ? 'Compartilhando...' : 'Compartilhar'}
                    </Button>
                </div>

                {/* Shared Users List */}
                {sharedUsers.length > 0 && (
                    <div className="space-y-3">
                        <h3 className="font-semibold text-slate-900">Usuários com Acesso</h3>
                        <div className="space-y-2">
                            {sharedUsers.map((share, index) => (
                                <div
                                    key={index}
                                    className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"
                                >
                                    <div className="flex items-center gap-3 flex-1 min-w-0">
                                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold shrink-0">
                                            {share.email?.charAt(0).toUpperCase() || '?'}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="font-medium text-slate-900 truncate">
                                                {share.email}
                                            </p>
                                            <div className="flex items-center gap-1.5 mt-0.5">
                                                {share.permission === 'edit' ? (
                                                    <>
                                                        <Edit2 size={14} className="text-green-600 shrink-0" />
                                                        <span className="text-xs text-green-600 font-medium truncate">
                                                            Pode editar
                                                        </span>
                                                    </>
                                                ) : (
                                                    <>
                                                        <Eye size={14} className="text-blue-600 shrink-0" />
                                                        <span className="text-xs text-blue-600 font-medium truncate">
                                                            Apenas visualizar
                                                        </span>
                                                    </>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => handleUnshareClick(share.email)}
                                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors shrink-0 ml-2"
                                        title="Remover acesso"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {sharedUsers.length === 0 && (
                    <div className="text-center py-8 text-slate-400">
                        <Users size={48} className="mx-auto mb-3 opacity-50" />
                        <p className="text-sm">Nenhum usuário com acesso ainda</p>
                    </div>
                )}
            </div>
        </Modal>
    );
};

export default ShareModal;
