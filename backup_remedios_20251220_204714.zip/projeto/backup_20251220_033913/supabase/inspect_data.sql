
SELECT * FROM public.sponsors;
SELECT count(*) FROM public.profiles;
SELECT * FROM public.profiles WHERE ibge_code = '3515509' LIMIT 5;
