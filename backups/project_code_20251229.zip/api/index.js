// Vercel Serverless Function Entry Point
import app from '../server/index.js';

export default app;
